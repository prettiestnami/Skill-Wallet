import { useState } from "react";

function App() {
  const [items, setItems] = useState(["Apple", "Banana", "Mango"]);
  const [newItem, setNewItem] = useState("");

  function addItem() {
    if (newItem.trim() === "") return;
    setItems([...items, newItem]);
    setNewItem("");
  }

  function removeItem(index) {
    const updated = items.filter((_, i) => i !== index);
    setItems(updated);
  }

  return (
    <div>
      <h1>Dynamic List Demo</h1>

      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
      />

      <button onClick={addItem}>Add</button>

      {items.length === 0 ? (
        <p>No items available</p>
      ) : (
        <ul>
          {items.map((item, index) => (
            <li key={index}>
              {item}
              <button onClick={() => removeItem(index)}>X</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;